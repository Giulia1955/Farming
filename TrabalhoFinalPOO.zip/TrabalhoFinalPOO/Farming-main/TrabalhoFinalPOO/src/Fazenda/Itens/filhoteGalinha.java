package Fazenda.Itens;

import java.io.Serializable;

public class filhoteGalinha extends Item implements Serializable {
    public filhoteGalinha(){
        super(20, "Um lindo pintinho", "Filhote de galinha");
    }
}
