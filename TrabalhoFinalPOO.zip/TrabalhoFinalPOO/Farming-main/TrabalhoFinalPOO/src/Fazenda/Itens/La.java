package Fazenda.Itens;
import java.io.Serializable;

public class La extends Item implements Serializable {
    public La() {
        super(30, "Já em forma de novelo", "Lã");
    }
}
