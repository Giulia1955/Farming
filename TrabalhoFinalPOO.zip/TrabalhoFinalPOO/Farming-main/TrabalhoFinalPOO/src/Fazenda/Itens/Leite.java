package Fazenda.Itens;
import java.io.Serializable;

public class Leite extends Item implements Serializable{
    public Leite(){
        super (3, "Garrafa de 2l", "Leite");
    }
}


