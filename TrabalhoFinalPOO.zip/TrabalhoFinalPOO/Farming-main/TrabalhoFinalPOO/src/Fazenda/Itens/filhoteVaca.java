package Fazenda.Itens;
import java.io.Serializable;

public class filhoteVaca extends Item implements Serializable{
    public filhoteVaca(){
        super(60, "Uma vaquinha!", "Filhote de vaca");
    }
}
