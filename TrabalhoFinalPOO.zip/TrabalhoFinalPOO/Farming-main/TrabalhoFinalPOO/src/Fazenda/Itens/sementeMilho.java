package Fazenda.Itens;
import java.io.Serializable;

public class sementeMilho extends Item implements Serializable {
    public sementeMilho(){
        super (5, "sementes de milho", "Semente Milho");
    }
}
