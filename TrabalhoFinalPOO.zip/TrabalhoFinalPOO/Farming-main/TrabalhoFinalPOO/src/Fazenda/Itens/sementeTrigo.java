package Fazenda.Itens;
import java.io.Serializable;

public class sementeTrigo extends Item implements Serializable {
    public sementeTrigo(){
        super (4, "sementes de trigo", "Semente Trigo");
    }
}
