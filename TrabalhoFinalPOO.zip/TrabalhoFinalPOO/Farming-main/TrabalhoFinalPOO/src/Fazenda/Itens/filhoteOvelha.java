package Fazenda.Itens;
import java.io.Serializable;

public class filhoteOvelha extends Item implements Serializable {
    public filhoteOvelha(){
        super(40, "Uma linda novilha", "Filhote de ovelha");
    }
}
