package Fazenda.Itens;
import java.io.Serializable;

public class sementeSoja extends Item implements Serializable {
    public sementeSoja(){
        super (7, "sementes de soja", "Semente Soja");
    }
}
