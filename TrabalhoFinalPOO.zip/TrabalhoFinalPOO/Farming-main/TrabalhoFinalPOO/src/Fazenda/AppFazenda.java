package Fazenda;


public class AppFazenda {
    public static void main(String[] args) {
        Controle controle = new Controle();
        controle.iniciar();
    }
}
