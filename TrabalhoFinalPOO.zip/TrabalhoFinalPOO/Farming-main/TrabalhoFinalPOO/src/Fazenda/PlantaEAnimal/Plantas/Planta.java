package Fazenda.PlantaEAnimal.Plantas;

import Fazenda.Itens.Item;
import Fazenda.Informacoes.Inventario;
import Fazenda.Informacoes.Lotes;

/**
 * Classe abstrata que representa uma planta cultivável na fazenda.
 * Cada planta possui um estado de sede, um item produzido, um nome, quantidade de produção
 * e dias restantes para a produção.
 * Inclui métodos para manipular seu estado e realizar o plantio.
 */
public abstract class Planta {
    private boolean sede;
    private Item itemProduzido;
    private String nome;
    private int QuantidadeProducao, diasParaProduzir;

    /**
     * Constrói uma planta com os atributos principais.
     *
     * @param sede estado inicial de sede da planta
     * @param itemProduzido item que será produzido após o crescimento
     * @param nome nome da planta
     * @param QuantidadeProducao quantidade de itens produzidos
     * @param diasParaProduzir número de dias necessários para produzir
     */
    public Planta(boolean sede, Item itemProduzido, String nome, int QuantidadeProducao, int diasParaProduzir) {
        this.itemProduzido = itemProduzido;
        this.sede = false;
        this.nome = nome;
        this.QuantidadeProducao = QuantidadeProducao;
        this.diasParaProduzir = diasParaProduzir;
    }

    /**
     * Retorna os dias restantes para a planta produzir.
     *
     * @return dias restantes para produção
     */
    public int getDiasParaProduzir() {
        return diasParaProduzir;
    }

    /**
     * Define os dias restantes para a produção da planta.
     *
     * @param diasParaProduzir novo valor de dias restantes
     */
    public void setDiasParaProduzir(int diasParaProduzir) {
        this.diasParaProduzir = diasParaProduzir;
    }

    /**
     * Indica se a planta está com sede.
     *
     * @return true se estiver com sede, false caso contrário
     */
    public boolean isSede() {
        return sede;
    }

    /**
     * Define o estado de sede da planta.
     *
     * @param sede novo estado de sede
     */
    public void setSede(boolean sede) {
        this.sede = sede;
    }

    /**
     * Retorna o item que a planta irá produzir.
     *
     * @return item produzido
     */
    public Item getItemProduzido() {
        return itemProduzido;
    }

    /**
     * Define o item que a planta irá produzir.
     *
     * @param itemProduzido novo item de produção
     */
    public void setItemProduzido(Item itemProduzido) {
        this.itemProduzido = itemProduzido;
    }

    /**
     * Retorna o nome da planta.
     *
     * @return nome da planta
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o nome da planta.
     *
     * @param nome novo nome da planta
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Retorna a quantidade de itens produzidos pela planta.
     *
     * @return quantidade de produção
     */
    public int getQuantidadeProducao() {
        return QuantidadeProducao;
    }

    /**
     * Define a quantidade de itens produzidos pela planta.
     *
     * @param quantidadeProducao nova quantidade de produção
     */
    public void setQuantidadeProducao(int quantidadeProducao) {
        QuantidadeProducao = quantidadeProducao;
    }

    /**
     * Rega a planta, removendo o estado de sede caso ela esteja com sede.
     */
    public void regar() {
        if (isSede()) {
            this.sede = false;
        }
    }

    /**
     * Método abstrato que define a lógica de plantio da planta.
     * Deve ser implementado pelas subclasses.
     *
     * @param lotes lotes da fazenda
     * @param inventario inventário da fazenda
     */
    public abstract void plantar(Lotes lotes, Inventario inventario);
}
