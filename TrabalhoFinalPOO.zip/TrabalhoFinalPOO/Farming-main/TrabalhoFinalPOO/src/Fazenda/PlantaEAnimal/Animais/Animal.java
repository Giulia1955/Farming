package Fazenda.PlantaEAnimal.Animais;

import Fazenda.Itens.Item;
import Fazenda.Informacoes.Inventario;
import Fazenda.Informacoes.Lotes;
import java.io.Serializable;

/**
 * Classe abstrata que representa um animal na fazenda.
 * Cada animal possui um nome, itens que produz e consome, estado de fome, vida útil, quantidade produzida,
 * tempo de produção e um filhote associado.
 * Contém métodos abstratos para alimentar o animal e colocá-lo no inventário/lote.
 *
 * @author Giulia, Guilherme e Eduardo
 */
public abstract class Animal implements Serializable {
    private Item itemProduzido, comida, filhote;
    private boolean fome;
    private int vida;
    private String nome;
    private int QuantidadeProducao, quantoCome, diasParaProduzir, diasEntreProducoes;

    /**
     * Construtor para inicializar um animal com seus atributos principais.
     *
     * @param nome nome do animal
     * @param itemProduzido item que o animal produz
     * @param fome estado de fome do animal
     * @param vida vida útil do animal em dias ou ciclos
     * @param comida item que o animal consome como alimento
     * @param QuantidadeProducao quantidade produzida pelo animal por ciclo
     * @param quantoCome quantidade de comida consumida por ciclo
     * @param diasParaProduzir dias necessários para o animal produzir um novo item
     * @param filhote item que representa o filhote do animal
     */
    public Animal(String nome, Item itemProduzido, boolean fome, int vida, Item comida, int QuantidadeProducao, int quantoCome, int diasParaProduzir, Item filhote){
        this.nome = nome;
        this.itemProduzido = itemProduzido;
        this.fome = fome;
        this.vida = vida;
        this.comida = comida;
        this.QuantidadeProducao = QuantidadeProducao;
        this.quantoCome = quantoCome;
        this.diasParaProduzir = diasParaProduzir;
        this.filhote = filhote;
        this.diasEntreProducoes = diasParaProduzir;
    }

    /**
     * Retorna o item produzido pelo animal.
     *
     * @return item produzido
     */
    public Item getItemProduzido() {
        return itemProduzido;
    }

    /**
     * Define o item produzido pelo animal.
     *
     * @param itemProduzido novo item produzido
     */
    public void setItemProduzido(Item itemProduzido) {
        this.itemProduzido = itemProduzido;
    }

    /**
     * Retorna o item que o animal consome como comida.
     *
     * @return item de comida
     */
    public Item getComida() {
        return comida;
    }

    /**
     * Define o item que o animal consome como comida.
     *
     * @param comida novo item de comida
     */
    public void setComida(Item comida) {
        this.comida = comida;
    }

    /**
     * Retorna se o animal está com fome.
     *
     * @return true se estiver com fome, false caso contrário
     */
    public boolean isFome() {
        return fome;
    }

    /**
     * Define o estado de fome do animal.
     *
     * @param fome novo estado de fome
     */
    public void setFome(boolean fome) {
        this.fome = fome;
    }

    /**
     * Retorna a vida útil do animal.
     *
     * @return vida do animal
     */
    public int getVida() {
        return vida;
    }

    /**
     * Define a vida útil do animal.
     *
     * @param vida nova vida útil
     */
    public void setVida(int vida) {
        this.vida = vida;
    }

    /**
     * Retorna a quantidade produzida pelo animal em cada ciclo.
     *
     * @return quantidade produzida
     */
    public int getQuantidadeProducao() {
        return QuantidadeProducao;
    }

    /**
     * Define a quantidade produzida pelo animal em cada ciclo.
     *
     * @param quantidadeProducao nova quantidade produzida
     */
    public void setQuantidadeProducao(int quantidadeProducao) {
        QuantidadeProducao = quantidadeProducao;
    }

    /**
     * Retorna o nome do animal.
     *
     * @return nome do animal
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o nome do animal.
     *
     * @param nome novo nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Retorna a quantidade de comida que o animal consome por ciclo.
     *
     * @return quantidade consumida
     */
    public int getQuantoCome() {
        return quantoCome;
    }

    /**
     * Define a quantidade de comida que o animal consome por ciclo.
     *
     * @param quantoCome nova quantidade consumida
     */
    public void setQuantoCome(int quantoCome) {
        this.quantoCome = quantoCome;
    }

    /**
     * Retorna o item que representa o filhote do animal.
     *
     * @return filhote do animal
     */
    public Item getFilhote() {
        return filhote;
    }

    /**
     * Define o item que representa o filhote do animal.
     *
     * @param filhote novo filhote
     */
    public void setFilhote(Item filhote) {
        this.filhote = filhote;
    }

    /**
     * Retorna os dias restantes para o animal produzir o próximo item.
     *
     * @return dias para produzir
     */
    public int getDiasParaProduzir() {
        return diasParaProduzir;
    }

    /**
     * Define os dias restantes para o animal produzir o próximo item.
     *
     * @param diasParaProduzir novo valor de dias restantes
     */
    public void setDiasParaProduzir(int diasParaProduzir) {
        this.diasParaProduzir = diasParaProduzir;
    }

    /**
     * Método abstrato para alimentar o animal, alterando o inventário e lotes conforme necessário.
     *
     * @param inventario inventário da fazenda
     * @param lotes lotes da fazenda
     */
    public abstract void alimentar(Inventario inventario, Lotes lotes);

    /**
     * Método abstrato para colocar o animal no inventário ou lotes.
     *
     * @param inventario inventário da fazenda
     * @param lotes lotes da fazenda
     */
    public abstract void colocar(Inventario inventario, Lotes lotes);

    /**
     * Indica se o animal está pronto para a coleta do item produzido.
     * Retorna true quando os dias para produzir chegam a zero ou menos.
     *
     * @return true se pronto para coleta, false caso contrário
     */
    public boolean prontoParaColeta() {
        return this.getDiasParaProduzir() <= 0;
    }

    /**
     * Retorna o intervalo em dias entre as produções do animal.
     *
     * @return dias entre produções
     */
    public int getDiasEntreProducoes() {
        return diasEntreProducoes;
    }
}
